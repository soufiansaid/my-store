const apps = [
  {
    name: "قوة الذاكرة",
    category: "games",
    description: "لعبة ممتعة يمكنك لعبها وتنزيلها بصيغة APK.",
    link: "https://silver-caren-84.tiiny.site",
    apk: "https://www.appcreator24.com/app3396458-uolgm7",
  }
];

function displayApps(filter = "all", search = "") {
  const appList = document.getElementById("app-list");
  appList.innerHTML = "";

  const filteredApps = apps.filter((app) => {
    return (
      (filter === "all" || app.category === filter) &&
      app.name.toLowerCase().includes(search.toLowerCase())
    );
  });

  filteredApps.forEach((app) => {
    const appCard = document.createElement("div");
    appCard.classList.add("app-card");
    appCard.innerHTML = `
      <h3>${app.name}</h3>
      <p>${app.description}</p>
      <a href="${app.link}" target="_blank" class="play-button">ابدأ اللعب</a>
      <a href="${app.apk}" target="_blank" class="download-button">تنزيل اللعبة</a>
    `;
    appList.appendChild(appCard);
  });
}

// إظهار النافذة المنبثقة عند الضغط على الزر
document.getElementById("login-button").addEventListener("click", () => {
  document.getElementById("password-modal").style.display = "flex";
});

// إغلاق النافذة المنبثقة
document.getElementById("close-modal").addEventListener("click", () => {
  document.getElementById("password-modal").style.display = "none";
});

// التحقق من الرمز السري
document.getElementById("submit-password").addEventListener("click", () => {
  const password = document.getElementById("password-input").value;
  if (password === "2008") {
    // إذا كان الرمز صحيحًا، الانتقال إلى صفحة نشر التطبيقات
    window.location.href = "publish.html";  // تأكد من أن الصفحة موجودة في نفس المجلد
  } else {
    alert("الرمز السري غير صحيح");
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const searchBox = document.getElementById("search-box");

  displayApps();

  searchBox.addEventListener("input", () => {
    const searchTerm = searchBox.value;
    displayApps("all", searchTerm);
  });

  document.getElementById("games-button").addEventListener("click", () => {
    displayApps("games");
  });

  document.getElementById("apps-button").addEventListener("click", () => {
    displayApps("apps");
  });
});
